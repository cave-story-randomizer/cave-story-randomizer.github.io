Tracker:AddItems("items/items.json")

if not (string.find(Tracker.ActiveVariantUID, "items_only")) then
    Tracker:AddMaps("maps/maps.json")
    ScriptHost:LoadScript("scripts/logic_common.lua")
    Tracker:AddLocations("locations/locations.json")    
end

Tracker:AddLayouts("layouts/tracker.json")
Tracker:AddLayouts("layouts/broadcast.json")
